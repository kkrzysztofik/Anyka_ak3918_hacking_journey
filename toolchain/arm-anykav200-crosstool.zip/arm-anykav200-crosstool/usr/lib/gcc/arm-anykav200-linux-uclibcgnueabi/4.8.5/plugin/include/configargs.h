/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/opt/arm-anykav200-crosstool/usr --sysconfdir=/opt/arm-anykav200-crosstool/etc --enable-static --target=arm-anykav200-linux-uclibcgnueabi --with-sysroot=/opt/arm-anykav200-crosstool/usr/arm-anykav200-linux-uclibcgnueabi/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/opt/arm-anykav200-crosstool/usr --with-mpfr=/opt/arm-anykav200-crosstool/usr --with-pkgversion='anyka (gcc-4.8.5 + binutils-2.24 + ulcibc-0.9.33.2)(20170223)' --with-bugurl=http://bugs.anyka.net/ --disable-libsanitizer --enable-tls --disable-libmudflap --enable-threads --with-mpc=/opt/arm-anykav200-crosstool/usr --without-isl --without-cloog --with-float=soft --disable-decimal-float --with-abi=aapcs-linux --with-cpu=arm926ej-s --with-float=soft --with-mode=arm --enable-languages=c,c++ --with-build-time-tools=/opt/arm-anykav200-crosstool/usr/arm-anykav200-linux-uclibcgnueabi/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs-linux" }, { "cpu", "arm926ej-s" }, { "float", "soft" }, { "mode", "arm" }, { "tls", "gnu" } };
